for i in range(5):
    print("Px sb")
print("程序执行完毕")
print("程序执行完毕")
print("程序执行完毕")
